# 07_Python_Code — dpkit và script 10 buổi

Bộ mã này tạo ra **mọi con số** trong slide, file Excel Solution và Forecasting Lab của khóa
*Demand Planning & Forecasting in Practice* (ERX). Học viên không bắt buộc dùng Python; phần này dành cho
giảng viên (tái tạo, cập nhật dữ liệu) và học viên muốn tự động hóa cho nhiều SKU.

## Cài đặt

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r 07_Python_Code/requirements.txt
```

Python 3.11 trở lên. Chạy mọi lệnh từ thư mục gốc của bộ tài liệu (nơi có `06_Data/` và `07_Python_Code/`).

## Cấu trúc

| Thư mục / file | Nội dung |
|---|---|
| `dpkit/data.py` | Đọc 13 bảng CSV của MBF, ghép mã kế hoạch (S06 → S06N) |
| `dpkit/metrics.py` | ME, Bias%, MAE, RMSE, MAPE, WMAPE, MASE, Tracking Signal, FVA |
| `dpkit/baseline.py` | Naive, Seasonal Naive, MA, WMA, drift |
| `dpkit/smoothing.py` | SES, Holt (có tắt dần), Holt-Winters cộng/nhân — tự cài đặt, khởi tạo giống file Excel |
| `dpkit/seasonal.py` | Chỉ số mùa vụ (tỷ lệ CMA 2×12), hiệu ứng Tết dịch tháng, phân bổ lại T12–T2 |
| `dpkit/regression.py` | Hồi quy OLS, baseline – uplift |
| `dpkit/promo.py` | Hiệu quả và lãi gộp khuyến mãi, sản phẩm mới |
| `dpkit/intermittent.py` | ADI/CV², phân loại SBC, Croston/SBA/TSB |
| `dpkit/classify.py` | ABC, XYZ (CV đã khử mùa vụ), bảng chính sách danh mục |
| `dpkit/cleaning.py` | Quy tắc làm sạch + nhật ký điều chỉnh (AdjustmentLog) |
| `dpkit/evaluation.py` | Train/test, cuốn chiếu (rolling origin), sai số theo lag, best-fit |
| `dpkit/hierarchy.py` | CV theo cấp, top-down / bottom-up |
| `dpkit/inventory.py` | Safety Stock, ROP, đường cong phục vụ, cảnh báo run-rate, hạn dùng FEFO, volume → value |
| `make_clean_dataset.py` | Tạo `06_Data/csv/demand_clean.csv` và nhật ký điều chỉnh tham chiếu |
| `sessions/Bxx_*.py` | Một script cho mỗi buổi: hàm `results()` + hình trong `sessions/imgs/` |
| `tests/` | Kiểm thử thước đo, mô hình và các con số then chốt trong slide |

## Quy trình tái tạo

```bash
python 06_Data/generate_dataset.py            # sinh dữ liệu MBF (seed 42) — chỉ khi muốn tạo lại
python 07_Python_Code/make_clean_dataset.py   # bản nhu cầu sạch của lớp
python 07_Python_Code/sessions/B05_mua_vu_tet.py   # in kết quả Buổi 5, vẽ hình
pytest 07_Python_Code/tests -q                # 11 kiểm thử
```

## Quy ước toàn khóa

* 36 tháng lịch sử 10/2023–09/2026; **train 30 tháng, test 6 tháng (04–09/2026)**.
* Tham số mô hình chọn trên train (tối thiểu SSE), không bao giờ trên test.
* Sai số e = thực tế − dự báo; Bias% = Σ(dự báo − thực tế)/Σ thực tế (dương = dự báo cao).
* σ trong Safety Stock = RMSE sai số dự báo 1 bước **ngoài mẫu** (cuốn chiếu 12 tháng cuối).

## Dùng an toàn với AI

Có thể nhờ trợ lý AI viết/sửa code, nhưng hãy kiểm chứng kết quả bằng một phép tính tay hoặc so với file
Excel Solution (xem *Manual Python Cơ Bản*, phần Vibe Coding an toàn). Không đưa dữ liệu thật chưa ẩn danh
của công ty vào công cụ AI công cộng.
