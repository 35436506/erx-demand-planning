"""Kiểm thử dpkit và các con số then chốt được trích trong slide / Excel Solution.
Chạy:  pytest 07_Python_Code/tests -q   (từ thư mục gốc của bộ tài liệu)"""
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "sessions"))

from dpkit import baseline, classify, intermittent, inventory, metrics, smoothing  # noqa: E402


# ---------- thước đo
def test_metrics_basic():
    a, f = np.array([100, 200, 300.0]), np.array([110, 180, 300.0])
    assert metrics.mae(a, f) == pytest.approx(10)
    assert metrics.wmape(a, f) == pytest.approx(30 / 600 * 100)
    assert metrics.me(a, f) == pytest.approx(10 / 3)          # e = thực tế − dự báo
    assert metrics.rmse(a, f) == pytest.approx(np.sqrt(500 / 3))


def test_mase_below_one_for_perfect():
    ins = np.arange(1, 25, dtype=float)
    assert metrics.mase([25, 26], [25, 26], ins) == pytest.approx(0)


def test_tracking_signal_sign():
    a = np.full(6, 100.0)
    f = np.full(6, 120.0)                                     # dự báo luôn cao
    assert metrics.tracking_signal(a, f)[-1] < 0


# ---------- mô hình
def test_naive_and_snaive():
    y = np.arange(1, 25, dtype=float)
    assert baseline.naive(y, 3).tolist() == [24, 24, 24]
    assert baseline.seasonal_naive(y, 2).tolist() == [13, 14]


def test_ses_constant_series():
    y = np.full(24, 50.0)
    r = smoothing.ses(y, 3)
    assert np.allclose(r.forecast, 50)


def test_holt_follows_trend():
    y = 100 + 5 * np.arange(30, dtype=float)
    r = smoothing.holt(y, 3)
    assert r.forecast[0] == pytest.approx(250, rel=0.02)


def test_croston_zero_periods():
    y = np.array([0, 0, 6, 0, 0, 4, 0, 5, 0, 0, 6, 0], dtype=float)
    adi, cv2 = intermittent.adi_cv2(y)
    assert adi > 1.32
    out = intermittent.croston(y, 3, variant="sba")
    assert np.all(np.asarray(out["forecast"]) > 0)


def test_classify():
    assert classify.xyz(0.10) == "X" and classify.xyz(0.25) == "Y" and classify.xyz(0.5) == "Z"


# ---------- tồn kho
def test_safety_stock_formula():
    ss = inventory.safety_stock(1000, 0.25, 0.95)
    assert ss == pytest.approx(1.6449 * 1000 * 0.5, rel=1e-3)


def test_run_rate_alert():
    al = inventory.run_rate_alert(700, 14, 28, 1000)
    assert al["run_rate_ratio"] == pytest.approx(1.4) and al["flag"].startswith("Bán nhanh")


# ---------- con số trích trong slide (khóa với dữ liệu seed 42)
def test_session_numbers_match_slides():
    import B08_demand_review_fva as S8
    import B09_ton_kho_sop as S9
    r8 = S8.results()
    tot = {d["step"]: d for d in r8["fva_total"]}
    assert tot["Naive"]["WMAPE%"] == pytest.approx(19.05, abs=0.05)
    assert tot["Thống kê"]["WMAPE%"] == pytest.approx(17.49, abs=0.05)
    assert tot["Đồng thuận"]["WMAPE%"] == pytest.approx(18.24, abs=0.05)
    r9 = S9.results()
    n01 = next(d for d in r9["ss"] if d["series"] == "N01|GT")
    assert n01["safety_stock"] == pytest.approx(5043, abs=2)
    assert r9["capacity_nov"]["gap"] == pytest.approx(12585, abs=2)
