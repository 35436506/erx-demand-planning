# 11_Automation_Kit · Báo cáo dự báo tự động: Excel VBA · Power BI · Python · AI

Tác giả: Thư Nguyễn (ERX) · thu.minh090997@gmail.com · Học phần *Demand Planning & Forecasting in Practice*

Bộ công cụ đi kèm **Lecture Notes Chương 22**. Cả ba cách đều tính cùng một bộ KPI trên dữ liệu MBF (`forecast_history.csv`, lag 1) và cho cùng con số tháng 2026-09 (cửa sổ 6 tháng):

| Chỉ số | Giá trị |
|---|---|
| WMAPE thống kê | 16,4% |
| WMAPE Sales | 21,8% |
| WMAPE đồng thuận | 18,1% |
| FVA thống kê → đồng thuận | −1,8 điểm % |
| Bias đồng thuận | +7,7% |

## Cấu trúc

```
Excel_VBA/
  ERX_DPF_BaoCao_TuDong.xlsx   Workbook công thức (chạy được ngay, không cần macro)
  VBA/modReport.bas            Nhập CSV, cập nhật chuỗi, ngoại lệ, nhận xét theo quy tắc
  VBA/modAI.bas                Nhận xét bằng LLM (OpenAI / Azure OpenAI / Anthropic) — bản nháp
  VBA/modExport.bas            Xuất PDF, soạn email Outlook (không tự gửi), tạo nút bấm
PowerBI/
  data/*.csv                   Star schema: FactForecast, FactDemand, DimSKU, DimDate, DimChannel
  PowerQuery.m                 Mã M nạp dữ liệu (tham số DataFolder)
  Measures.dax                 Toàn bộ measure: WMAPE, Bias, FVA, Tracking Signal, cửa sổ 6 tháng, ngoại lệ, câu nhận xét
  ERX_theme.json               Theme màu ERX
  Copilot_prompts.md           Prompt Copilot, tính năng AI có sẵn, nguyên tắc dùng AI
  python_visual_fan.py         Python visual: biểu đồ quạt khoảng dự báo
Python/
  auto_report.py               Cùng quy trình bằng Python: KPI, ngoại lệ, dashboard PNG, Excel, nhận xét (+ AI tùy chọn)
```

## Bắt đầu nhanh

**Excel (không macro):** mở `ERX_DPF_BaoCao_TuDong.xlsx`, đổi tháng ở `Config!B3` → sheet KPI và Dashboard tự tính lại.

**Excel + VBA:**
1. Lưu thành `.xlsm`.
2. `Alt + F11` → *File → Import File…* → nhập 3 file `.bas`.
3. Chạy macro `AddRunButton` một lần → bấm nút **Tạo báo cáo tháng**.
4. (Tùy chọn) Điền đường dẫn CSV mới vào `Config!B10` để nạp dữ liệu tháng mới.
5. (Tùy chọn AI) `Config!B13 = TRUE`, chọn nhà cung cấp, endpoint, model; đặt khóa API vào biến môi trường
   `ERX_AI_API_KEY` (Windows: `setx ERX_AI_API_KEY "…"` rồi mở lại Excel). Khóa không lưu trong file.

Mã VBA chỉ dùng ký tự ASCII để VBE đọc đúng trên mọi máy; chữ tiếng Việt có dấu nằm trong sheet `Config` và `Templates`. Macro AI dùng `MSXML2.ServerXMLHTTP` nên chỉ chạy trên Excel for Windows.

**Power BI Desktop:** tạo tham số `DataFolder` → dán từng query trong `PowerQuery.m` → tạo quan hệ → dán measure trong `Measures.dax` → *View → Themes → Browse* chọn `ERX_theme.json` → dựng 4 trang theo Lecture Notes mục 22.4.

**Python:**
```
pip install pandas matplotlib openpyxl
python auto_report.py --data ../../06_Data/csv --month 2026-09 --window 6 --out output
# AI tùy chọn: đặt ERX_AI_API_KEY, ERX_AI_PROVIDER (openai|anthropic), ERX_AI_MODEL rồi thêm --ai
```

## Lưu ý trung thực

- Workbook và script Python đã được chạy và đối chiếu số liệu. Mã VBA và DAX được viết theo cú pháp chuẩn nhưng **chưa chạy trên Excel/Power BI thật** trong môi trường soạn tài liệu. Hãy chạy thử trên máy của bạn trước khi đưa vào quy trình, và báo lỗi (nếu có) để chỉnh.
- Tên model AI và tính năng Copilot thay đổi theo thời gian và theo giấy phép; điền tên model hiện hành của nhà cung cấp.
- Đoạn nhận xét do AI viết luôn là **bản nháp**; người phụ trách phải duyệt trước khi gửi.
