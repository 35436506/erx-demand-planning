# Power BI Python visual — biểu đồ quạt: thực tế, số đồng thuận và khoảng 80% thực nghiệm
# Kéo vào Values: FactForecast[month], [Actual], [Consensus] (Don't summarize theo tháng)
# Tác giả: Thư Nguyễn · thu.minh090997@gmail.com
import matplotlib.pyplot as plt
import numpy as np

df = dataset.dropna().sort_values("month")  # noqa: F821  (Power BI cung cấp biến dataset)
df = df.groupby("month", as_index=False)[["Actual", "Consensus"]].sum()
err = (df["Actual"] - df["Consensus"]).to_numpy()
lo, hi = np.quantile(err, [0.10, 0.90])

fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(df["month"], df["Actual"], color="#1F2421", lw=2, label="Thực tế")
ax.plot(df["month"], df["Consensus"], color="#008A3A", lw=2, label="Đồng thuận")
ax.fill_between(df["month"], df["Consensus"] + lo, df["Consensus"] + hi, color="#008A3A", alpha=0.18, label="Khoảng 80% (sai số lịch sử)")
ax.set_ylabel("Thùng")
ax.legend(frameon=False, loc="upper left")
ax.grid(alpha=0.3)
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
plt.tight_layout()
plt.show()
