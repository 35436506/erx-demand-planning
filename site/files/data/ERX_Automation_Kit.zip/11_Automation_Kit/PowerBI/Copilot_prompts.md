# Dùng AI trong Power BI và Excel cho báo cáo dự báo

Tác giả: Thư Nguyễn · thu.minh090997@gmail.com

> Tính năng AI của Microsoft thay đổi nhanh và phụ thuộc giấy phép (Copilot, Fabric capacity) cùng cài đặt của quản trị viên tenant. Hãy kiểm tra trên môi trường của công ty trước khi đưa vào quy trình.

## 1. Copilot trong Power BI (cần giấy phép / capacity phù hợp)

**Tạo trang báo cáo**

- "Tạo trang tổng quan độ chính xác dự báo gồm thẻ WMAPE Consensus 6M, FVA 6M, Bias Consensus 6M, Exceptions Count, biểu đồ đường Actual – Stat Forecast – Consensus theo DimDate[date], và bảng ngoại lệ theo SKU, kênh với Exception Reason."
- "Thêm trang phân tích FVA theo ngành hàng và theo kênh, sắp xếp giảm dần theo Error Value 6M."

**Viết DAX** (luôn kiểm tra lại kết quả bằng số liệu đã biết)

- "Viết measure tính WMAPE theo từng dòng của FactForecast, không lấy ABS của tổng."
- "Viết measure Tracking Signal 6 tháng kết thúc ở tháng đang chọn, không dùng hàm time intelligence."

**Tóm tắt (narrative)**

- "Tóm tắt 3 điểm chính về độ chính xác dự báo tháng này cho ban giám đốc, nêu chuỗi có sai số giá trị lớn nhất và đề xuất hành động. Chỉ dùng số liệu trong báo cáo."

## 2. Tính năng AI có sẵn không cần Copilot

| Tính năng | Dùng cho Demand Planning |
|---|---|
| **Narrative visual** (trước đây gọi là Smart narrative) | Chế độ *Custom*: đoạn văn tự cập nhật theo slicer, chèn giá trị measure. Chế độ *Copilot* (cần giấy phép Copilot): AI viết tóm tắt từ dữ liệu báo cáo |
| **Anomaly detection** (Line chart → Analytics) | Đánh dấu tháng bất thường của Actual — gợi ý kiểm tra dữ liệu (Chương 2) |
| **Key influencers** | Yếu tố nào làm WMAPE cao: kênh, ngành, promo_flag, segment ABC-XYZ |
| **Decomposition tree** | Bóc tách Error Value theo ngành → SKU → kênh để tìm nguồn sai số |
| **Q&A** | Đặt câu hỏi bằng tiếng Anh: "consensus vs actual by category last 6 months" |
| **Forecast** (Line chart → Analytics) | Dự báo ETS nhanh để tham khảo — KHÔNG thay thế dự báo đã kiểm chứng ngoài mẫu |
| **Python / R visual** | Biểu đồ quạt khoảng dự báo (python_visual_fan.py) |

## 3. Copilot trong Excel

- Dùng **Copilot trong Excel** (khung chat, cần giấy phép Microsoft 365 Copilot) để: phân loại lý do điều chỉnh trong nhật ký, tóm tắt ghi chú Demand Review, gợi ý công thức, giải thích biến động trên sheet Dashboard. Luôn kiểm tra lại và lưu kết quả đã duyệt thành giá trị.
- Lưu ý: hàm ô `=COPILOT(...)` chỉ là tính năng xem trước (preview) và **Microsoft đã ngừng hỗ trợ từ 14/09/2026** — ô đã tính giữ giá trị cũ nhưng khi tính lại sẽ báo `#NAME?`. Bài học: không xây báo cáo định kỳ trên tính năng preview; bộ kit dùng macro `modAI` (gọi API do công ty phê duyệt) và luôn có nhận xét theo quy tắc chạy được khi tắt AI.
- Câu lệnh mẫu cho khung chat: *"Dựa trên bảng ở sheet Exceptions, phân loại lý do ngoại lệ thành: khuyến mãi, đơn lớn, thiếu hàng, dữ liệu, khác — trả về bảng 2 cột."*

## 4. Nguyên tắc dùng AI có trách nhiệm trong báo cáo dự báo

1. Con số đi vào kế hoạch phải được tính bằng công thức/mã **tái tạo được**; AI chỉ viết lời, gợi ý, tìm bất thường.
2. Gửi **số liệu tổng hợp**; không gửi dữ liệu khách hàng, giá bán, kế hoạch chưa công bố lên dịch vụ ngoài khi chưa được phép.
3. Mọi đoạn AI viết là **bản nháp** — người phụ trách ký duyệt trước khi gửi.
4. Ghi lại phiên bản prompt, model và ngày chạy trong báo cáo (sheet Report đã có dấu thời gian).
5. Đánh giá định kỳ: AI có nêu sai số liệu không? Có bỏ sót ngoại lệ lớn không?
