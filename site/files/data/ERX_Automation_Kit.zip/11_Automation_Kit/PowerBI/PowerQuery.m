// =============================================================================
// ERX · Power Query (M) — nạp bộ dữ liệu MBF vào Power BI Desktop
// Tác giả: Thư Nguyễn · thu.minh090997@gmail.com
//
// B1. Home → Transform data → Manage Parameters → New: tên DataFolder, kiểu Text,
//     giá trị = đường dẫn thư mục data, có dấu \ ở cuối, ví dụ C:\ERX\PowerBI\data\
// B2. Với mỗi query dưới đây: New Source → Blank Query → Advanced Editor → dán đoạn tương ứng,
//     đổi tên query đúng như tiêu đề (FactForecast, FactDemand, DimSKU, DimDate, DimChannel).
// B3. Close & Apply → Model view: tạo quan hệ như ghi trong Measures.dax.
// Khi có dữ liệu tháng mới: chép đè CSV vào thư mục → Refresh (hoặc lịch refresh qua gateway).
// =============================================================================

// ----- Query: FactForecast
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactForecast.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers  = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Headers, {
                   {"month", type date}, {"origin", type date}, {"lag", Int64.Type}, {"sku", type text}, {"channel", type text},
                   {"stat_forecast", type number}, {"sales_input", type number}, {"consensus", type number},
                   {"actual", type number}, {"promo_flag", Int64.Type}}, "en-US"),
    Lag1     = Table.SelectRows(Typed, each [lag] = 1)          // chấm độ chính xác ở lag 1 (đổi nếu cần)
in
    Lag1

// ----- Query: FactDemand
let
    Source   = Csv.Document(File.Contents(DataFolder & "FactDemand.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers  = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Headers, {
                   {"month", type date}, {"sku", type text}, {"channel", type text}, {"recorded", type number},
                   {"demand", type number}, {"stockout_days", type number}, {"event_flag", type text}}, "en-US")
in
    Typed

// ----- Query: DimSKU
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimSKU.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers  = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Headers, {
                   {"sku", type text}, {"name", type text}, {"category", type text}, {"price_k", type number}, {"cost_k", type number},
                   {"shelf_life_days", Int64.Type}, {"lead_time_weeks", type number}, {"supply_type", type text},
                   {"ABC", type text}, {"XYZ", type text}, {"segment", type text}}, "en-US")
in
    Typed

// ----- Query: DimDate (theo tháng, có tỷ trọng Tết)
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimDate.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers  = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Headers, {
                   {"date", type date}, {"year", Int64.Type}, {"month_num", Int64.Type}, {"quarter", type text}, {"month_label", type text},
                   {"days_in_month", Int64.Type}, {"tet_pre_share", type number}, {"tet_post_share", type number}}, "en-US")
in
    Typed

// ----- Query: DimChannel
let
    Source   = Csv.Document(File.Contents(DataFolder & "DimChannel.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Headers  = Table.PromoteHeaders(Source, [PromoteAllScalars = true])
in
    Headers
