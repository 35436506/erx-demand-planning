Attribute VB_Name = "modReport"
Option Explicit
'==============================================================================
' ERX - Demand Planning & Forecasting in Practice
' Bao cao du bao thang tu dong (Excel VBA)
' Tac gia: Thu Nguyen - thu.minh090997@gmail.com
'
' Cach dung: Developer > Visual Basic > File > Import File... (modReport.bas,
' modAI.bas, modExport.bas) > luu file duoi dang .xlsm > chay RunMonthlyReport.
' Ma nguon chi dung ky tu ASCII de VBE doc dung tren moi may; chu tieng Viet
' co dau nam trong cac o cua sheet Config / Templates.
'==============================================================================

Private Const DATA_FIRST As Long = 2
Private Const KPI_FIRST As Long = 5
Private Const EXC_FIRST As Long = 5
Private Const REPORT_FIRST As Long = 7

Public Sub RunMonthlyReport()
    Dim t0 As Double, csvPath As String, pdfFile As String
    t0 = Timer
    On Error GoTo Fail
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual

    csvPath = Trim$(CStr(Cfg("B10")))
    If Len(csvPath) > 0 Then
        If Len(Dir$(csvPath)) = 0 Then Err.Raise vbObjectError + 1, , "Khong tim thay file CSV: " & csvPath
        ImportForecastCSV csvPath
        RebuildSeriesList
    End If

    Application.Calculation = xlCalculationAutomatic
    Application.CalculateFull

    BuildExceptions
    WriteRuleCommentary
    If CBool(Cfg("B13")) Then WriteAICommentary

    pdfFile = ExportReportPDF()
    If Len(Trim$(CStr(Cfg("B12")))) > 0 Then EmailReport pdfFile

    Application.ScreenUpdating = True
    MsgBox "Da tao bao cao thang " & Cfg("B3") & " trong " & Format(Timer - t0, "0.0") & " giay." & vbCrLf & pdfFile, vbInformation, "ERX"
    Exit Sub
Fail:
    Application.Calculation = xlCalculationAutomatic
    Application.ScreenUpdating = True
    MsgBox "Loi: " & Err.Description, vbExclamation, "ERX"
End Sub

' Gia tri mot o tren sheet Config
Public Function Cfg(addr As String) As Variant
    Cfg = ThisWorkbook.Worksheets("Config").Range(addr).Value
End Function

'------------------------------------------------------------------------------
' Nhap forecast_history.csv (target_month, origin_month, lag, sku, channel,
' stat_forecast, sales_input, consensus, actual_shipments, promo_flag)
'------------------------------------------------------------------------------
Public Sub ImportForecastCSV(ByVal path As String)
    Dim wb As Workbook, src As Worksheet, ws As Worksheet
    Dim v As Variant, outArr() As Variant
    Dim i As Long, n As Long, r As Long, lastRow As Long, lagWanted As Long
    Dim m As Variant

    lagWanted = CLng(Cfg("B7"))
    Set ws = ThisWorkbook.Worksheets("Data")
    Set wb = Workbooks.Open(Filename:=path, ReadOnly:=True)          ' Local mac dinh = False: doc CSV theo dau phay (en-US)
    Set src = wb.Worksheets(1)
    v = src.UsedRange.Value
    wb.Close SaveChanges:=False

    ReDim outArr(1 To UBound(v, 1), 1 To 11)
    n = 0
    For i = 2 To UBound(v, 1)
        If Len(CStr(v(i, 1))) > 0 Then
            If CLng(v(i, 3)) = lagWanted Then
                n = n + 1
                m = v(i, 1)
                If IsDate(m) Then m = Format$(m, "yyyy-mm")      ' Excel co the doi "2025-10" thanh ngay
                outArr(n, 1) = CStr(m)
                outArr(n, 2) = CStr(v(i, 4))
                outArr(n, 3) = CStr(v(i, 5))
                outArr(n, 7) = CDbl(v(i, 6))
                outArr(n, 8) = CDbl(v(i, 7))
                outArr(n, 9) = CDbl(v(i, 8))
                outArr(n, 10) = CDbl(v(i, 9))
                outArr(n, 11) = CDbl(v(i, 10))
            End If
        End If
    Next i
    If n = 0 Then Err.Raise vbObjectError + 2, , "CSV khong co dong nao voi lag = " & lagWanted

    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    If lastRow >= DATA_FIRST Then ws.Range("A" & DATA_FIRST & ":Q" & lastRow).ClearContents

    For r = 1 To n
        ws.Cells(DATA_FIRST + r - 1, 1).NumberFormat = "@"
        ws.Cells(DATA_FIRST + r - 1, 1).Value = outArr(r, 1)
        ws.Cells(DATA_FIRST + r - 1, 2).Value = outArr(r, 2)
        ws.Cells(DATA_FIRST + r - 1, 3).Value = outArr(r, 3)
        ws.Range(ws.Cells(DATA_FIRST + r - 1, 7), ws.Cells(DATA_FIRST + r - 1, 11)).Value = _
            Array(outArr(r, 7), outArr(r, 8), outArr(r, 9), outArr(r, 10), outArr(r, 11))
    Next r

    ' cong thuc phu tro (giong ban mau) - dung R1C1 de moi dong tu tham chieu dung dong cua no
    With ws
        .Range("D" & DATA_FIRST & ":D" & DATA_FIRST + n - 1).FormulaR1C1 = "=RC2&""|""&RC3"
        .Range("E" & DATA_FIRST & ":E" & DATA_FIRST + n - 1).FormulaR1C1 = "=IFERROR(INDEX(Dim_SKU!R2C3:R200C3,MATCH(RC2,Dim_SKU!R2C1:R200C1,0)),"""")"
        .Range("F" & DATA_FIRST & ":F" & DATA_FIRST + n - 1).FormulaR1C1 = "=IFERROR(INDEX(Dim_SKU!R2C4:R200C4,MATCH(RC2,Dim_SKU!R2C1:R200C1,0)),0)"
        .Range("L" & DATA_FIRST & ":L" & DATA_FIRST + n - 1).FormulaR1C1 = "=VALUE(LEFT(RC1,4))*12+VALUE(RIGHT(RC1,2))"
        .Range("M" & DATA_FIRST & ":M" & DATA_FIRST + n - 1).FormulaR1C1 = "=ABS(RC10-RC7)"
        .Range("N" & DATA_FIRST & ":N" & DATA_FIRST + n - 1).FormulaR1C1 = "=ABS(RC10-RC8)"
        .Range("O" & DATA_FIRST & ":O" & DATA_FIRST + n - 1).FormulaR1C1 = "=ABS(RC10-RC9)"
        .Range("P" & DATA_FIRST & ":P" & DATA_FIRST + n - 1).FormulaR1C1 = "=RC10-RC9"
        .Range("Q" & DATA_FIRST & ":Q" & DATA_FIRST + n - 1).FormulaR1C1 = "=RC15*RC6/1000"
    End With
End Sub

' Danh sach chuoi (sku|kenh) duy nhat tren sheet KPI + chep cong thuc xuong
Public Sub RebuildSeriesList()
    Dim ws As Worksheet, k As Worksheet, d As Object
    Dim lastRow As Long, i As Long, n As Long, key As Variant, lastK As Long

    Set ws = ThisWorkbook.Worksheets("Data")
    Set k = ThisWorkbook.Worksheets("KPI")
    Set d = CreateObject("Scripting.Dictionary")
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For i = DATA_FIRST To lastRow
        key = CStr(ws.Cells(i, 2).Value) & "|" & CStr(ws.Cells(i, 3).Value)
        If Not d.Exists(key) Then d.Add key, 1
    Next i

    lastK = k.Cells(k.Rows.Count, 1).End(xlUp).Row
    If lastK > KPI_FIRST Then k.Range("A" & KPI_FIRST + 1 & ":O" & lastK).ClearContents

    n = 0
    For Each key In d.Keys
        k.Cells(KPI_FIRST + n, 1).Value = key
        n = n + 1
    Next key
    If n > 1 Then k.Range("B" & KPI_FIRST & ":O" & KPI_FIRST).Copy Destination:=k.Range("B" & KPI_FIRST + 1 & ":O" & KPI_FIRST + n - 1)
End Sub

'------------------------------------------------------------------------------
' Danh sach ngoai le: |TS| vuot nguong, WMAPE vuot nguong, hoac FVA < 0
' Sap xep giam dan theo gia tri sai so (trieu dong)
'------------------------------------------------------------------------------
Public Sub BuildExceptions()
    Dim k As Worksheet, e As Worksheet
    Dim lastK As Long, i As Long, j As Long, n As Long, c As Long
    Dim arr() As Variant, tmp As Variant
    Dim wm As Double, ts As Double, fva As Variant, reason As String
    Dim thrW As Double, thrT As Double

    Set k = ThisWorkbook.Worksheets("KPI")
    Set e = ThisWorkbook.Worksheets("Exceptions")
    thrW = CDbl(Cfg("B8")): thrT = CDbl(Cfg("B9"))
    lastK = k.Cells(k.Rows.Count, 1).End(xlUp).Row
    If lastK < KPI_FIRST Then Exit Sub

    ReDim arr(1 To lastK - KPI_FIRST + 1)
    n = 0
    For i = KPI_FIRST To lastK
        ' cot O (Co) do cong thuc tinh: khac rong = ngoai le
        If Len(CStr(k.Cells(i, 15).Value)) > 0 Then
            ts = CDbl(k.Cells(i, 13).Value)
            fva = k.Cells(i, 11).Value
            reason = ""
            If Abs(ts) > thrT Then reason = reason & "TS " & Format(ts, "0.0") & "; "
            If IsNumeric(k.Cells(i, 10).Value) And Len(CStr(k.Cells(i, 10).Value)) > 0 Then
                wm = CDbl(k.Cells(i, 10).Value)
                If wm > thrW Then reason = reason & "WMAPE " & Format(wm, "0%") & "; "
            Else
                wm = 0
                reason = reason & "Thuc te = 0; "
            End If
            If IsNumeric(fva) And Len(CStr(fva)) > 0 Then
                If CDbl(fva) < 0 Then reason = reason & "FVA am; "
            End If
            If Len(reason) = 0 Then reason = "Ngoai le; "
            n = n + 1
            arr(n) = Array(k.Cells(i, 1).Value, k.Cells(i, 4).Value, k.Cells(i, 10).Value, fva, k.Cells(i, 12).Value, ts, k.Cells(i, 14).Value, Left$(reason, Len(reason) - 2))
        End If
    Next i

    ' sap xep theo gia tri sai so (cot 7) giam dan
    For i = 1 To n - 1
        For j = i + 1 To n
            If CDbl(arr(j)(6)) > CDbl(arr(i)(6)) Then
                tmp = arr(i): arr(i) = arr(j): arr(j) = tmp
            End If
        Next j
    Next i

    e.Range("A" & EXC_FIRST & ":H" & EXC_FIRST + 300).ClearContents
    For i = 1 To n
        For c = 0 To 7
            e.Cells(EXC_FIRST + i - 1, c + 1).Value = arr(i)(c)
        Next c
    Next i
    e.Range("B2").Value = n
End Sub

'------------------------------------------------------------------------------
' Nhan xet theo quy tac (khong can AI): thay the {...} trong cac cau mau o sheet
' Templates bang so lieu tren Dashboard / Exceptions.
'------------------------------------------------------------------------------
Public Sub WriteRuleCommentary()
    Dim t As Worksheet, rp As Worksheet, d As Worksheet, e As Worksheet
    Dim i As Long, s As String, r As Long, fva As Double, nSer As Long, nExc As Long

    Set t = ThisWorkbook.Worksheets("Templates")
    Set rp = ThisWorkbook.Worksheets("Report")
    Set d = ThisWorkbook.Worksheets("Dashboard")
    Set e = ThisWorkbook.Worksheets("Exceptions")
    fva = CDbl(d.Range("E4").Value)
    nSer = Application.WorksheetFunction.CountA(ThisWorkbook.Worksheets("KPI").Range("A5:A400"))
    nExc = CLng(e.Range("B2").Value)

    rp.Range("A" & REPORT_FIRST & ":A27").ClearContents
    r = REPORT_FIRST
    For i = 2 To 12
        s = CStr(t.Cells(i, 2).Value)
        If Len(s) > 0 Then
            ' cau dieu kien: cot A = "FVA<0" hoac "FVA>=0"
            If (t.Cells(i, 1).Value = "FVA<0" And fva >= 0) Or (t.Cells(i, 1).Value = "FVA>=0" And fva < 0) Then GoTo NextLine
            If t.Cells(i, 1).Value = "EXC>50%" And nExc <= 0.5 * nSer Then GoTo NextLine
            s = Replace(s, "{MONTH}", CStr(Cfg("B3")))
            s = Replace(s, "{WINDOW}", CStr(Cfg("B4")))
            s = Replace(s, "{WMAPE_STAT}", Format(d.Range("B4").Value, "0.0%"))
            s = Replace(s, "{WMAPE_SALES}", Format(d.Range("C4").Value, "0.0%"))
            s = Replace(s, "{WMAPE_CONS}", Format(d.Range("D4").Value, "0.0%"))
            s = Replace(s, "{FVA}", Format(Abs(fva) * 100, "0.0"))
            s = Replace(s, "{BIAS}", Format(d.Range("F4").Value, "+0.0%;-0.0%"))
            s = Replace(s, "{N_EXC}", CStr(nExc))
            s = Replace(s, "{N_SERIES}", CStr(nSer))
            s = Replace(s, "{TOP1}", CStr(e.Range("A" & EXC_FIRST).Value))
            s = Replace(s, "{TOP1_REASON}", CStr(e.Range("H" & EXC_FIRST).Value))
            rp.Cells(r, 1).Value = s
            r = r + 1
        End If
NextLine:
    Next i
    rp.Range("B3").Value = Now
End Sub
