Attribute VB_Name = "modAI"
Option Explicit
'==============================================================================
' ERX - Nhan xet bao cao bang mo hinh ngon ngu lon (LLM) - BAN NHAP, can nguoi duyet
' Tac gia: Thu Nguyen - thu.minh090997@gmail.com
'
' Ho tro 3 kieu API (sheet Config, o B14):
'   openai    : POST {endpoint}  header  Authorization: Bearer <key>     -> choices[0].message.content
'   azure     : POST {endpoint}  header  api-key: <key>                  -> choices[0].message.content
'   anthropic : POST {endpoint}  header  x-api-key, anthropic-version    -> content[0].text
' Khoa API KHONG luu trong file: doc tu bien moi truong ten o Config!B17
' (Windows: setx ERX_AI_API_KEY "..." roi mo lai Excel).
' Chi gui so lieu tong hop (KPI, ma chuoi) - khong gui du lieu khach hang/gia ban.
' Chi chay tren Excel for Windows (dung MSXML2.ServerXMLHTTP).
'==============================================================================

Public Sub WriteAICommentary()
    Dim prompt As String, reply As String, rp As Worksheet, lines() As String
    Dim i As Long, r As Long

    prompt = BuildPrompt()
    reply = CallLLM(prompt)

    Set rp = ThisWorkbook.Worksheets("Report")
    rp.Range("A30:A90").ClearContents
    rp.Range("A29").Value = ThisWorkbook.Worksheets("Templates").Range("B14").Value   ' tieu de "Nhan xet AI (ban nhap)..."
    lines = Split(Replace(reply, vbCr, ""), vbLf)
    r = 30
    For i = LBound(lines) To UBound(lines)
        If Len(Trim$(lines(i))) > 0 Then
            rp.Cells(r, 1).Value = lines(i)
            r = r + 1
        End If
    Next i
    rp.Range("B29").Value = "AI " & Format(Now, "yyyy-mm-dd hh:nn")
End Sub

' Ghep cau lenh: mau tieng Viet (Config!B20) + so lieu tong hop
Public Function BuildPrompt() As String
    Dim d As Worksheet, e As Worksheet, s As String, i As Long
    Set d = ThisWorkbook.Worksheets("Dashboard")
    Set e = ThisWorkbook.Worksheets("Exceptions")

    s = CStr(Cfg("B20")) & vbLf & vbLf
    s = s & "SO LIEU (cua so " & Cfg("B4") & " thang, ket thuc " & Cfg("B3") & "):" & vbLf
    s = s & "- WMAPE thong ke: " & Format(d.Range("B4").Value, "0.0%") & vbLf
    s = s & "- WMAPE Sales: " & Format(d.Range("C4").Value, "0.0%") & vbLf
    s = s & "- WMAPE dong thuan: " & Format(d.Range("D4").Value, "0.0%") & vbLf
    s = s & "- FVA (thong ke -> dong thuan, diem %): " & Format(d.Range("E4").Value * 100, "0.0") & vbLf
    s = s & "- Bias dong thuan: " & Format(d.Range("F4").Value, "+0.0%;-0.0%") & vbLf
    s = s & "- So chuoi ngoai le: " & e.Range("B2").Value & vbLf
    s = s & "NGOAI LE (chuoi | nhom | WMAPE | FVA | Bias | TS | sai so trieu dong | ly do):" & vbLf
    For i = 5 To 14
        If Len(CStr(e.Cells(i, 1).Value)) = 0 Then Exit For
        s = s & e.Cells(i, 1).Value & " | " & e.Cells(i, 2).Value & " | " & Format(e.Cells(i, 3).Value, "0%") & " | " & _
            Format(Val(CStr(e.Cells(i, 4).Value)) * 100, "0.0") & " | " & Format(e.Cells(i, 5).Value, "0%") & " | " & _
            Format(e.Cells(i, 6).Value, "0.0") & " | " & Format(e.Cells(i, 7).Value, "#,##0") & " | " & e.Cells(i, 8).Value & vbLf
    Next i
    BuildPrompt = s
End Function

Public Function CallLLM(ByVal prompt As String) As String
    Dim http As Object, provider As String, url As String, model As String, key As String
    Dim body As String, maxTok As Long

    provider = LCase$(Trim$(CStr(Cfg("B14"))))
    url = Trim$(CStr(Cfg("B15")))
    model = Trim$(CStr(Cfg("B16")))
    key = Environ$(Trim$(CStr(Cfg("B17"))))
    maxTok = 900
    If Len(key) = 0 Then
        CallLLM = "[Chua co khoa API trong bien moi truong " & Cfg("B17") & " - bo qua buoc AI]"
        Exit Function
    End If

    If provider = "anthropic" Then
        body = "{""model"":""" & JsonEscape(model) & """,""max_tokens"":" & maxTok & _
               ",""messages"":[{""role"":""user"",""content"":""" & JsonEscape(prompt) & """}]}"
    Else
        body = "{""model"":""" & JsonEscape(model) & """,""max_tokens"":" & maxTok & ",""temperature"":0.2," & _
               """messages"":[{""role"":""system"",""content"":""You are a careful demand planning analyst. Use only the numbers provided. Answer in Vietnamese.""}," & _
               "{""role"":""user"",""content"":""" & JsonEscape(prompt) & """}]}"
    End If

    On Error GoTo Fail
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "POST", url, False
    http.setTimeouts 5000, 5000, 30000, 90000
    http.setRequestHeader "Content-Type", "application/json"
    Select Case provider
        Case "anthropic"
            http.setRequestHeader "x-api-key", key
            http.setRequestHeader "anthropic-version", "2023-06-01"
        Case "azure"
            http.setRequestHeader "api-key", key
        Case Else
            http.setRequestHeader "Authorization", "Bearer " & key
    End Select
    http.send body

    If http.Status <> 200 Then
        CallLLM = "[Loi API " & http.Status & "] " & Left$(http.responseText, 400)
        Exit Function
    End If
    If provider = "anthropic" Then
        CallLLM = JsonStringValue(http.responseText, "text")
    Else
        CallLLM = JsonStringValue(http.responseText, "content")
    End If
    Exit Function
Fail:
    CallLLM = "[Khong goi duoc API: " & Err.Description & "]"
End Function

' Chuoi -> chuoi JSON an toan (ky tu ngoai ASCII doi thanh \uXXXX)
Public Function JsonEscape(ByVal s As String) As String
    Dim i As Long, ch As String, code As Long, out As String
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        If code < 0 Then code = code + 65536
        Select Case code
            Case 34: out = out & "\"""
            Case 92: out = out & "\\"
            Case 10: out = out & "\n"
            Case 13: out = out & "\r"
            Case 9: out = out & "\t"
            Case 32 To 126: out = out & ch
            Case Else: out = out & "\u" & Right$("000" & Hex$(code), 4)
        End Select
    Next i
    JsonEscape = out
End Function

' Lay gia tri chuoi dau tien cua khoa "key" trong JSON (du cho phan hoi LLM)
Public Function JsonStringValue(ByVal json As String, ByVal key As String) As String
    Dim p As Long, i As Long, ch As String, out As String, hx As String
    p = InStr(1, json, """" & key & """:")              ' tim KHOA (co dau hai cham), khong tim GIA TRI
    If p = 0 Then p = InStr(1, json, """" & key & """ :")
    If p = 0 Then JsonStringValue = "[Khong doc duoc phan hoi] " & Left$(json, 300): Exit Function
    p = InStr(p + Len(key) + 2, json, ":") + 1
    Do While Mid$(json, p, 1) = " " Or Mid$(json, p, 1) = vbLf Or Mid$(json, p, 1) = vbCr Or Mid$(json, p, 1) = vbTab
        p = p + 1
    Loop
    If Mid$(json, p, 1) <> """" Then JsonStringValue = "[Phan hoi khong phai chuoi] " & Left$(json, 300): Exit Function
    i = p + 1
    Do While i <= Len(json)
        ch = Mid$(json, i, 1)
        If ch = "\" Then
            i = i + 1
            ch = Mid$(json, i, 1)
            Select Case ch
                Case "n": out = out & vbLf
                Case "r": out = out & vbCr
                Case "t": out = out & vbTab
                Case "b", "f":
                Case "u"
                    hx = Mid$(json, i + 1, 4)
                    out = out & ChrW(Val("&H" & hx & "&"))
                    i = i + 4
                Case Else: out = out & ch          ' \"  \\  \/
            End Select
        ElseIf ch = """" Then
            Exit Do
        Else
            out = out & ch
        End If
        i = i + 1
    Loop
    JsonStringValue = out
End Function
