Attribute VB_Name = "modExport"
Option Explicit
'==============================================================================
' ERX - Xuat PDF va soan email (KHONG tu dong gui: nguoi phu trach kiem tra roi bam Send)
' Tac gia: Thu Nguyen - thu.minh090997@gmail.com
'==============================================================================

Public Function ExportReportPDF() As String
    Dim folder As String, f As String, sep As String, cur As Worksheet
    sep = Application.PathSeparator
    folder = Trim$(CStr(Cfg("B11")))
    If Len(folder) = 0 Then folder = ThisWorkbook.Path & sep & "Reports"
    If Len(Dir$(folder, vbDirectory)) = 0 Then MkDir folder
    f = folder & sep & "ERX_BaoCaoDuBao_" & Cfg("B3") & ".pdf"

    Set cur = ActiveSheet
    ThisWorkbook.Activate
    ThisWorkbook.Worksheets(Array("Dashboard", "Exceptions", "Report")).Select
    ActiveSheet.ExportAsFixedFormat Type:=xlTypePDF, Filename:=f, Quality:=xlQualityStandard, _
        IncludeDocProperties:=True, IgnorePrintAreas:=False, OpenAfterPublish:=False
    ThisWorkbook.Worksheets("Dashboard").Select
    cur.Activate
    ExportReportPDF = f
End Function

Public Sub EmailReport(ByVal pdfFile As String)
    Dim ol As Object, m As Object
    On Error GoTo NoOutlook
    Set ol = CreateObject("Outlook.Application")
    Set m = ol.CreateItem(0)
    With m
        .To = CStr(Cfg("B12"))
        .Subject = "ERX - Bao cao du bao thang " & Cfg("B3")
        .Body = CStr(ThisWorkbook.Worksheets("Templates").Range("B16").Value) & vbCrLf & vbCrLf & _
                ThisWorkbook.Worksheets("Report").Range("A7").Value & vbCrLf & _
                ThisWorkbook.Worksheets("Report").Range("A8").Value
        .Attachments.Add pdfFile
        .Display                      ' de nguoi dung kiem tra truoc khi gui
    End With
    Exit Sub
NoOutlook:
    MsgBox "Khong mo duoc Outlook - file PDF da luu tai: " & pdfFile, vbInformation, "ERX"
End Sub

' Gan macro cho nut bam tren sheet Dashboard (chay mot lan sau khi import)
Public Sub AddRunButton()
    Dim ws As Worksheet, b As Object
    Set ws = ThisWorkbook.Worksheets("Dashboard")
    On Error Resume Next
    ws.Buttons("btnRun").Delete
    On Error GoTo 0
    Set b = ws.Buttons.Add(ws.Range("I1").Left, ws.Range("I1").Top, 170, 26)
    b.Name = "btnRun"
    b.Caption = "Tao bao cao thang"
    b.OnAction = "RunMonthlyReport"
End Sub
