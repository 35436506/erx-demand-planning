"""ERX · Báo cáo dự báo tháng tự động bằng Python (tương đương bộ Excel VBA và Power BI).

Chạy:   python auto_report.py --data ../../06_Data/csv --month 2026-09 --window 6 --out output
Tùy chọn AI:  đặt biến môi trường ERX_AI_API_KEY (và ERX_AI_PROVIDER = openai | anthropic, ERX_AI_MODEL)
              rồi thêm cờ --ai. Không có khóa → dùng nhận xét theo quy tắc.
Tác giả: Thư Nguyễn · thu.minh090997@gmail.com
"""
import argparse
import json
import os
import urllib.request
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

INK, GREEN, BLUE, ORANGE, RED, GRAY = "#1F2421", "#008A3A", "#2563C9", "#D9720B", "#C0392B", "#76777B"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10.5, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": "#E6E8E6", "savefig.dpi": 200, "savefig.bbox": "tight", "savefig.facecolor": "white"})


def pct(x, d=1, sign=False):
    s = f"{x * 100:+.{d}f}%" if sign else f"{x * 100:.{d}f}%"
    return s.replace(".", ",")


def load(data_dir: Path):
    fh = pd.read_csv(data_dir / "forecast_history.csv", encoding="utf-8-sig")
    sku = pd.read_csv(data_dir / "sku_master.csv", encoding="utf-8-sig").drop_duplicates("planning_item")
    sku = sku.rename(columns={"planning_item": "item"})[["item", "name", "category", "price_k"]]
    fh = fh[fh.lag == 1].merge(sku, left_on="sku", right_on="item", how="left")
    fh["idx"] = fh.target_month.str[:4].astype(int) * 12 + fh.target_month.str[5:].astype(int)
    fh["series"] = fh.sku + "|" + fh.channel
    return fh


def kpis(fh, month, window):
    end = int(month[:4]) * 12 + int(month[5:]); start = end - window + 1
    w = fh[(fh.idx >= start) & (fh.idx <= end)].copy()
    w["ae_stat"] = (w.actual_shipments - w.stat_forecast).abs()
    w["ae_sales"] = (w.actual_shipments - w.sales_input).abs()
    w["ae_cons"] = (w.actual_shipments - w.consensus).abs()
    w["e_cons"] = w.actual_shipments - w.consensus
    w["val_err"] = w.ae_cons * w.price_k / 1000
    A = w.actual_shipments.sum()
    tot = {"wmape_stat": w.ae_stat.sum() / A, "wmape_sales": w.ae_sales.sum() / A, "wmape_cons": w.ae_cons.sum() / A, "bias": w.consensus.sum() / A - 1}
    tot["fva"] = tot["wmape_stat"] - tot["wmape_cons"]
    g = w.groupby("series").agg(category=("category", "first"), actual=("actual_shipments", "sum"), ae_stat=("ae_stat", "sum"), ae_cons=("ae_cons", "sum"),
                                e=("e_cons", "sum"), n=("e_cons", "size"), cons=("consensus", "sum"), value=("val_err", "sum"))
    g["wmape_stat"], g["wmape_cons"] = (g.ae_stat / g.actual).where(g.actual > 0), (g.ae_cons / g.actual).where(g.actual > 0)
    g["fva"] = g.wmape_stat - g.wmape_cons
    g["bias"] = g.cons / g.actual - 1
    g["ts"] = g.e / (g.ae_cons / g.n)
    flag = (g.ts.abs() > 4) | (g.wmape_cons > 0.25) | (g.fva < 0) | (g.actual == 0)

    def why(r):
        out = []
        if abs(r.ts) > 4:
            out.append(f"TS {r.ts:.1f}".replace(".", ","))
        if r.wmape_cons > 0.25:
            out.append(f"WMAPE {r.wmape_cons * 100:.0f}%")
        if r.fva < 0:
            out.append("FVA âm")
        if r.actual == 0:
            out.append("thực tế = 0")
        return "; ".join(out)

    exc = g[flag].copy(); exc["reason"] = exc.apply(why, axis=1); exc = exc.sort_values("value", ascending=False)
    tot["n_exc"] = int(len(exc)); tot["n_series"] = int(len(g))
    monthly = fh[(fh.idx > end - 12) & (fh.idx <= end)].groupby("target_month")[["actual_shipments", "stat_forecast", "consensus"]].sum()
    cat = w.groupby("category").agg(actual=("actual_shipments", "sum"), ae_stat=("ae_stat", "sum"), ae_cons=("ae_cons", "sum"))
    cat["wmape_stat"], cat["wmape_cons"] = cat.ae_stat / cat.actual, cat.ae_cons / cat.actual
    return tot, g, exc, monthly, cat


def rule_narrative(month, window, tot, exc):
    lines = [f"Báo cáo dự báo tháng {month} — cửa sổ {window} tháng gần nhất (lag 1).",
             f"• Độ chính xác: WMAPE thống kê {pct(tot['wmape_stat'])}, Sales {pct(tot['wmape_sales'])}, số đồng thuận {pct(tot['wmape_cons'])}."]
    if tot["fva"] < 0:
        lines.append(f"• Bước điều chỉnh đồng thuận đang làm dự báo KÉM đi {abs(tot['fva']) * 100:.1f} điểm % so với dự báo thống kê — cần rà soát điều chỉnh tay.".replace(".", ",", 1))
    else:
        lines.append(f"• Bước điều chỉnh đồng thuận cải thiện {tot['fva'] * 100:.1f} điểm % so với dự báo thống kê.".replace(".", ",", 1))
    lines.append(f"• Bias của số đồng thuận {pct(tot['bias'], sign=True)} (dương = dự báo cao hơn thực tế → rủi ro tồn kho).")
    if len(exc):
        lines.append(f"• Có {len(exc)}/{tot['n_series']} chuỗi ngoại lệ; lớn nhất về giá trị sai số: {exc.index[0]} ({exc.reason.iloc[0]}).")
        if len(exc) > 0.5 * tot["n_series"]:
            lines.append("• Hơn một nửa danh mục là ngoại lệ → vấn đề mang tính HỆ THỐNG (bias chung của số đồng thuận), cần xử lý ở cấp quy trình thay vì sửa từng mã.")
    lines.append("• Đề xuất: đưa các chuỗi ngoại lệ vào Demand Review; kiểm tra giả định khuyến mãi và nhật ký điều chỉnh của các chuỗi FVA âm.")
    return lines


def ai_narrative(prompt):
    """Gọi LLM (OpenAI-compatible hoặc Anthropic). Chỉ gửi số liệu tổng hợp. Trả None nếu không cấu hình."""
    key = os.environ.get("ERX_AI_API_KEY")
    if not key:
        return None
    provider = os.environ.get("ERX_AI_PROVIDER", "openai").lower()
    model = os.environ.get("ERX_AI_MODEL", "gpt-4.1-mini")
    if provider == "anthropic":
        url = os.environ.get("ERX_AI_ENDPOINT", "https://api.anthropic.com/v1/messages")
        body = {"model": model, "max_tokens": 900, "messages": [{"role": "user", "content": prompt}]}
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    else:
        url = os.environ.get("ERX_AI_ENDPOINT", "https://api.openai.com/v1/chat/completions")
        body = {"model": model, "max_tokens": 900, "temperature": 0.2, "messages": [
            {"role": "system", "content": "You are a careful demand planning analyst. Use only the numbers provided. Answer in Vietnamese."},
            {"role": "user", "content": prompt}]}
        headers = {"Authorization": f"Bearer {key}", "content-type": "application/json"}
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=90) as r:
        res = json.loads(r.read().decode("utf-8"))
    return res["content"][0]["text"] if provider == "anthropic" else res["choices"][0]["message"]["content"]


def build_prompt(month, window, tot, exc):
    rows = "\n".join(f"{s} | {r.category} | WMAPE {pct(r.wmape_cons, 0)} | FVA {r.fva * 100:+.1f} | Bias {pct(r.bias, 0, True)} | TS {r.ts:.1f} | {r.value:,.0f} tr.đ | {r.reason}"
                     for s, r in exc.head(10).iterrows())
    return ("Bạn là chuyên viên Demand Planning. Dựa CHỈ trên số liệu bên dưới, viết nhận xét báo cáo dự báo tháng bằng tiếng Việt, tối đa 200 từ: "
            "(1) tóm tắt một câu; (2) ba điểm chính về độ chính xác, FVA, bias; (3) ba chuỗi cần hành động kèm đề xuất; (4) một rủi ro tháng tới. "
            "Không bịa số liệu.\n\n"
            f"Tháng {month}, cửa sổ {window} tháng. WMAPE thống kê {pct(tot['wmape_stat'])}, Sales {pct(tot['wmape_sales'])}, đồng thuận {pct(tot['wmape_cons'])}; "
            f"FVA {tot['fva'] * 100:+.1f} điểm %; Bias {pct(tot['bias'], 1, True)}; {tot['n_exc']} chuỗi ngoại lệ.\nNgoại lệ:\n{rows}")


def dashboard_png(path, month, window, tot, exc, monthly, cat):
    fig = plt.figure(figsize=(13, 7.4))
    gs = fig.add_gridspec(3, 12, height_ratios=[0.55, 1.5, 1.45], hspace=0.55, wspace=0.9)
    cards = [("WMAPE thống kê", pct(tot["wmape_stat"]), INK), ("WMAPE đồng thuận", pct(tot["wmape_cons"]), INK),
             ("FVA (điểm %)", f"{tot['fva'] * 100:+.1f}".replace(".", ","), RED if tot["fva"] < 0 else GREEN), ("Bias đồng thuận", pct(tot["bias"], 1, True), ORANGE),
             ("Chuỗi ngoại lệ", str(tot["n_exc"]), RED), ("Cửa sổ", f"{window} tháng", GRAY)]
    for j, (lab, val, col) in enumerate(cards):
        ax = fig.add_subplot(gs[0, 2 * j:2 * j + 2]); ax.axis("off")
        ax.add_patch(plt.Rectangle((0, 0), 1, 1, transform=ax.transAxes, fc="#F4F6F5", ec="none"))
        ax.text(0.06, 0.72, lab, transform=ax.transAxes, fontsize=9.5, color=GRAY)
        ax.text(0.06, 0.18, val, transform=ax.transAxes, fontsize=19, fontweight="bold", color=col)
    ax = fig.add_subplot(gs[1, :7])
    x = pd.to_datetime(monthly.index + "-01")
    ax.plot(x, monthly.actual_shipments, color=INK, lw=2.2, label="Thực tế")
    ax.plot(x, monthly.stat_forecast, color=BLUE, lw=1.8, label="Thống kê")
    ax.plot(x, monthly.consensus, color=GREEN, lw=1.8, label="Đồng thuận")
    ax.set_title("Thực tế và dự báo 12 tháng (tổng, thùng)", loc="left", fontsize=11.5, fontweight="bold")
    ax.legend(frameon=False, fontsize=9, ncol=3, loc="upper left"); ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v / 1000:,.0f}k"))
    ax = fig.add_subplot(gs[1, 9:])
    c2 = cat.sort_values("wmape_cons")
    yy = np.arange(len(c2)); h = 0.38
    ax.barh(yy - h / 2, c2.wmape_stat * 100, h, color=BLUE, label="Thống kê"); ax.barh(yy + h / 2, c2.wmape_cons * 100, h, color=GREEN, label="Đồng thuận")
    ax.set_yticks(yy, c2.index, fontsize=9); ax.set_title("WMAPE theo ngành (%)", loc="left", fontsize=11.5, fontweight="bold"); ax.legend(frameon=False, fontsize=8.5)
    ax = fig.add_subplot(gs[2, :]); ax.axis("off")
    top = exc.head(7)
    cols = ["Chuỗi", "Ngành", "WMAPE ĐT", "FVA", "Bias", "TS", "Giá trị |e| (tr.đ)", "Lý do"]
    cell = [[s, r.category, pct(r.wmape_cons) if r.wmape_cons == r.wmape_cons else "—", f"{r.fva * 100:+.1f}".replace(".", ","), pct(r.bias, 1, True), f"{r.ts:.1f}".replace(".", ","), f"{r.value:,.0f}".replace(",", "."), r.reason]
            for s, r in top.iterrows()]
    tb = ax.table(cellText=cell, colLabels=cols, loc="upper center", cellLoc="left", colWidths=[0.09, 0.14, 0.09, 0.07, 0.08, 0.06, 0.13, 0.3])
    tb.auto_set_font_size(False); tb.set_fontsize(9.5); tb.scale(1, 1.45)
    for (r_, c_), ce in tb.get_celld().items():
        ce.set_edgecolor("#E0E3E1")
        if r_ == 0:
            ce.set_facecolor(GREEN); ce.set_text_props(color="white", fontweight="bold")
    ax.set_title(f"Ngoại lệ cần đưa vào Demand Review (top {len(top)} theo giá trị sai số)", loc="left", fontsize=11.5, fontweight="bold")
    fig.suptitle(f"Báo cáo dự báo tháng {month} · Mekong Bloom Foods", x=0.01, ha="left", fontsize=15, fontweight="bold")
    fig.savefig(path); plt.close(fig)


def excel_report(path, month, window, tot, g, exc, lines):
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        pd.DataFrame({"Chỉ số": ["Tháng", "Cửa sổ (tháng)", "WMAPE thống kê", "WMAPE Sales", "WMAPE đồng thuận", "FVA (điểm %)", "Bias đồng thuận", "Số ngoại lệ"],
                      "Giá trị": [month, window, round(tot["wmape_stat"], 4), round(tot["wmape_sales"], 4), round(tot["wmape_cons"], 4), round(tot["fva"] * 100, 2),
                                  round(tot["bias"], 4), tot["n_exc"]]}).to_excel(xw, sheet_name="TongQuan", index=False)
        g.reset_index().round(4).to_excel(xw, sheet_name="KPI_Chuoi", index=False)
        exc.reset_index().round(4).to_excel(xw, sheet_name="NgoaiLe", index=False)
        pd.DataFrame({"Nhận xét": lines}).to_excel(xw, sheet_name="NhanXet", index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="../../06_Data/csv"); ap.add_argument("--month", default="2026-09"); ap.add_argument("--window", type=int, default=6)
    ap.add_argument("--out", default="output"); ap.add_argument("--ai", action="store_true")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    fh = load(Path(a.data))
    tot, g, exc, monthly, cat = kpis(fh, a.month, a.window)
    lines = rule_narrative(a.month, a.window, tot, exc)
    if a.ai:
        txt = ai_narrative(build_prompt(a.month, a.window, tot, exc))
        lines += ["", "Nhận xét AI (bản nháp — cần người duyệt):"] + (txt.splitlines() if txt else ["(Chưa cấu hình ERX_AI_API_KEY)"])
    dashboard_png(out / f"dashboard_{a.month}.png", a.month, a.window, tot, exc, monthly, cat)
    excel_report(out / f"ERX_BaoCao_{a.month}.xlsx", a.month, a.window, tot, g, exc, lines)
    (out / f"nhan_xet_{a.month}.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in tot.items()}, ensure_ascii=False))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
