# Python cơ bản cho Demand Planner (giáo trình bổ trợ)

Khóa học không bắt buộc lập trình. Thư mục này dành cho học viên muốn xử lý nhiều SKU, tự động hóa báo cáo, hoặc đọc và kiểm chứng code.

| Thư mục / file | Nội dung |
|---|---|
| `ERX_DPF_Python_Co_Ban.pdf` / `.docx` | Giáo trình gồm 10 chương. Code và kết quả in trong sách được lấy từ chính các notebook đã chạy thử |
| `notebooks/` | 9 notebook bản học viên (NB00–NB08), có ô để tự làm bài tập |
| `notebooks_loi_giai/` | Bản lời giải, đã chạy sẵn và có kết quả |
| `data/` | 13 bảng CSV của Mekong Bloom Foods |
| `dpkit/` | Thư viện tính toán của khóa (giống Forecasting Lab) |
| `requirements.txt` | Danh sách thư viện cần cài |

**Bắt đầu nhanh:** chạy `pip install -r requirements.txt`, rồi `jupyter lab`, mở `notebooks/NB00_CaiDat_KiemTra.ipynb`. Nếu không cài được phần mềm trên máy, dùng Google Colab (xem Chương 0 của giáo trình).
